from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def home(request):
    if request.method == 'POST':
        background_color = request.POST['background_color']
        txt_color = request.POST['txt_col']
        context = {'col' : background_color, 'txt_col': txt_color}
        return render(request, 'home.html', context)
    return render(request, 'home.html')


